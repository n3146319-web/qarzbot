# QarzBot — Netlify'da Telegram bot

## 1. Tokenni oling
Eski token ochiq yozilgan — @BotFather → /mybots → botingiz → API Token → **Revoke current token**.
Yangi tokenni faqat Netlify env'ga qo'ying (kodga yozmang).

## 2. Deploy
GitHub'ga yuklang → Netlify → Add new site → Import from Git.
Site settings → Environment variables:
- `BOT_TOKEN` = yangi token
- `WEBHOOK_SECRET` = ixtiyoriy uzun tasodifiy qator (masalan 32 ta harf/raqam)

Keyin Deploys → Trigger deploy.

## 3. Webhook'ni ulang (bir marta)
```
curl "https://api.telegram.org/bot<BOT_TOKEN>/setWebhook" \
  -d "url=https://<SAYT-NOMI>.netlify.app/api/webhook" \
  -d "secret_token=<WEBHOOK_SECRET>"
```
Tekshirish: `https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo`

## 4. Ishlatish
Botga /start yozing. Qarz: `Karim 50000 15.09`. Eslatmalar har kuni 09:00 (Toshkent).
Premium berish: Netlify → Blobs → `qarzbot` → `user-<chat_id>` ichida `"premium": true`.
